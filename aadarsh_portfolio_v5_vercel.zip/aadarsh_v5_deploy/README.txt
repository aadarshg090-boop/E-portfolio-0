Aadarsh Gupta Portfolio V5

Deployment package for Vercel static hosting.
1. Extract this ZIP.
2. In Vercel, choose Add New -> Project -> Deploy without Git (or upload via the Vercel dashboard's supported flow).
3. Upload the extracted folder containing index.html.

The website is a single self-contained static HTML page; portrait image is embedded.
